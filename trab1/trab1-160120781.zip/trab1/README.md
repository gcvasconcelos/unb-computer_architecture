# Trabalho 1: Memória do MIPS

Implementação das instruções de leitura e escrita do MIPS, desenvolvida na linguagem C.

Para compilação do código foi utilizado o compilador gcc, no sistema operacional elementary OS 0.4.1 Loki. Para a edição do código foi utilizado o software Visual Studio Code.

Também foi desenvolvido um [relatório]() da implementação do trabalho.